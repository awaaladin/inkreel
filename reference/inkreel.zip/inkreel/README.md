# Inkreel

Type what you want in a terminal. An AI director draws and animates it as a hand-inked 2D cartoon in a live browser preview, then exports MP4.

- Characters are jointed cut-out puppets drawn procedurally with wobbly "boiling" ink lines and paper grain. They are not AI images, so the same character looks identical in every shot.
- Library of ~35 hand-keyed actions (punches, slashes, dodges, blocks, hit reactions, knockdowns, gestures, emotes), a `strike` macro that syncs attack, reaction, impact, shake and sound-text on the contact frame, camera moves, speech bubbles, captions, weather, time of day.
- The director can web-search to research (a place, a martial art, an animation technique), saves notes, and applies them. It asks short questions when your request is genuinely unclear.

## Setup (once)

    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=sk-ant-...        # needed only for the AI director
    # for MP4 export: Node.js 18+ and ffmpeg on your PATH (the renderer installs itself on first /export)

## Run

    python -m inkreel my-series         # project folder is created if missing; browser opens

Try `/demo` first (no API key needed), then talk to it:

    make a beach duel at dusk, Kabi with a huge blade vs Ogun with a staff, 12 seconds
    make the knockdown bigger and push the camera in
    research how anime fights use smear frames and impact frames, then apply it
    add a scene where Ogun explains why he betrayed the village, night, campfire

Commands: `/play /export /still /status /scenes /research /undo /redo /demo /model /think /clear /open /quit` (see `/help`).

Project data is plain JSON in `my-series/project.json`; exports go in `my-series/exports/`.
Options: `--port N`, `--no-browser`, `--model NAME` (or env `INKREEL_MODEL`), `--think`, `--no-search`.

## Limits

Side-view puppets only (no turnarounds), no audio, no imported art. Fully custom moves are possible through joint keyframes, which the director writes for you.
